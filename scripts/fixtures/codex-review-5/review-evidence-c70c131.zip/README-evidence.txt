Commit: c70c13134b0dae8e82c34927021e8c95b1642eec
Decision: RETURN FOR CHANGES. One root cause, C1/C2: openDb calls all initializeDb data hygiene on every CLI open, changing pre-existing self-test-fleet outcomes even in health-probe --dry-run.
Independent cases: 38; conforms 31; nonconforms 7, all same root cause. The JSON is authoritative; the runner itself exits 0 after writing it.
Reproduce from the verified clone after npm ci --offline --no-audit --no-fund and npm run build:
  Copy independent-c70c131.mjs from this archive to work/independent-c70c131.mjs.
  node work/independent-c70c131.mjs
The runner uses only temporary fake DB rows; all CLI fetch is disabled. It creates a fresh work/ subdirectory each run. It reads 775a797 schema and CLI blobs from this clone for the regression baseline; no other checkout is opened.
For the Windows fixture-newline failure, copy normalize-fixture-newlines.mjs to work/ then run:
  node --import ./work/normalize-fixture-newlines.mjs scripts/smoke-codex-review-5-dc319cf.mjs
Only reads of the three fixture runner text files are LF-normalized in memory. The Git configuration and all tracked files stay unchanged.
commands-results.json records important command outcomes. smoke-*.log are captured original command outputs. coverage-c70c131.json lists files by review depth, including unreviewed files.
