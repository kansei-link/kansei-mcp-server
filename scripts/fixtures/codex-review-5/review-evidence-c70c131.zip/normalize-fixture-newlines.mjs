import fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
const original = fs.readFileSync;
fs.readFileSync = function(path, ...args) {
  const value = original.call(this, path, ...args);
  return typeof value === 'string' && String(path).replaceAll('\\', '/').includes('/scripts/fixtures/codex-review-5/') && String(path).endsWith('.mjs.txt')
    ? value.replaceAll('\r\n', '\n') : value;
};
syncBuiltinESMExports();
